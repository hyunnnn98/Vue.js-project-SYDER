<template>
  <div class="page-box">
    <h1 class="page-header">로그인 페이지</h1>
    <login-form></login-form>
  </div>
</template>

<script>
import LoginForm from '@/components/LoginForm';

export default {
  components: {
    LoginForm,
  },
};
</script>

<style></style>
