<template>
  <div class="footer">
    Copyright ⓒYJU WDJ Bokvengers. All rights reserved.
  </div>
</template>

<script>
export default {};
</script>

<style>
.footer {
  width: 100%;
  height: 50px;
  line-height: 50px;
  text-align: center;
  font-size: 0.9rem;
  font-weight: bold;
  background-color: rgba(45, 211, 147, 0.87);
  color: white;
  /* background-color: #2b8ddd;
  color: #4a4e52;
  border-top: 3px solid rgba(3, 181, 235, 0.815); */
}
</style>
