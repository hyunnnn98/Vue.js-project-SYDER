module.exports = {
  transpileDependencies: ['vuetify'],
  devServer: {
    overlay: false,
  },
};
